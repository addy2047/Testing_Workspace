package TOP;

public class ConcateSTR {

	    public static void main(String args[]) 

	    {

	        String str1 = "Computer "; 
	        String str2 = "Engineering"; 
	        String str3 = str1.concat(str2); 
	        								System.out.println(str3); 
	        String str4 = " Portal"; 
	        String str5 = str3.concat(str4); 
	        								System.out.println(str5); 

	    } 
	}

