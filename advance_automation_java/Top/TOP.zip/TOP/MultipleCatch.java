package TOP;

public class MultipleCatch {

}
