package TOP;

public class compareSTR {

	
	
	public static void main(String[] args) {
		String s1,s2,s3,s4;
		s1 ="hello";
		s2 ="hello";
		s3 ="how are U";
		s4 ="Fine";
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s2==s3);
		System.out.println(s4==s1);
		
	}
}
