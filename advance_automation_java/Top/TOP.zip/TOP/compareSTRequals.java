package TOP;

public class compareSTRequals {

	
	
	public static void main(String[] args) {
		String s1,s2;
		s1 ="hello";
		s2 ="hell";
		
		System.out.println(s1.equals(s2));
		
	}
}
